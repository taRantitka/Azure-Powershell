Configuration Main
{

Param ( [string] $nodeName )

Import-DscResource -ModuleName PSDesiredStateConfiguration

Node $nodeName
  {

	File index.htm
	{
		DestinationPath = "c:\inetpub\wwwroot\index/htm"
		Contents = "<head></head><body><h1>Task 4</h1></body>"
		Checksum = 'SHA-256'
		Force = $true
		DependsOn = "[WindowsFeature]IIS"
	}

	xWebSite NewWebsite
	{
		Ensure = 'Present'
		Name = 'Default Web Site'
		State = 'Started'
		PhysicalPath = 'c:\inetpub\wwwroot'
		BindInfo = MSFT_xWebBindingInformation
		{
			Protocol = 'HTTP'
			Port = '8080'
			IPAddress = '*'
		}
	}
  }
}